#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<stdlib.h>
#include<signal.h>
#include<sys/wait.h>
#include<string.h>
#include<sys/signal.h>
void main()
{
	int pid;
	char comm[40], temp[10];
	pid=fork();
	if(pid==0)
	{
	printf("This is child process\n");
	printf("Child process, Child pid: %d, Parent pid: %d\n",pid,getpid());
	printf("\n\n");
	system("ps");
	printf("\n\n");
	}
	else if(pid>0)
	{
	printf("This is parent process\n");
	printf("Parent before wait, Child pid: %d, Parent pid: %d\n",pid,getpid());
	wait(0);
	printf("Child process completed.\n");
	printf("Parent after wait, Child pid: %d, Parent pid: %d\n",pid,getpid());
	strcpy(comm,"kill -9 ");
	printf("\n\n");
	system("ps");
	printf("\n\n");
	printf("Enter the process to kill: ");
	scanf("%s",&temp);
	strcat(comm, temp);
	system(comm);
	execl("/usr/bin/gedit","gedit",0,0);
	}
	else
	{
	printf("Error\n");
	}
}

/*
Output:

root@kali:~# wc &
[2] 4321
root@kali:~# ./a.out
This is parent process
Parent before wait, Child pid: 4323, Parent pid: 4322
This is child process
Child process, Child pid: 0, Parent pid: 4323


  PID TTY          TIME CMD
 4281 pts/0    00:00:00 bash
 4315 pts/0    00:00:00 a.out
 4321 pts/0    00:00:00 wc
 4322 pts/0    00:00:00 a.out
 4323 pts/0    00:00:00 a.out
 4324 pts/0    00:00:00 sh
 4325 pts/0    00:00:00 ps


Child process completed.
Parent after wait, Child pid: 4323, Parent pid: 4322


  PID TTY          TIME CMD
 4281 pts/0    00:00:00 bash
 4315 pts/0    00:00:00 a.out
 4321 pts/0    00:00:00 wc
 4322 pts/0    00:00:00 a.out
 4326 pts/0    00:00:00 sh
 4327 pts/0    00:00:00 ps


Enter the process to kill: 4321
[2]+  Killed                  wc
root@kali:~# 

*/
/*
fork()
wait(0)
execl("path","name",arg0,arg1) or execl("path","name",array)
ps
kill
*/
