import java.io.*;
import java.util.*;
public class pass1 {
	public static void main(String args[]) throws Exception {
		BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("/root/Documents/TE Sem II/SPOSL/Final/A1/AssemblerPass1/src/in.asm")));
		FileWriter fw = new FileWriter("src/out.txt",true);
	    BufferedWriter bw = new BufferedWriter(fw);
	    PrintWriter out = new PrintWriter(bw);
		func f=new func();
		String s,wr;
		s=in.readLine();
		while(s!=null)
		{
			StringTokenizer st=new StringTokenizer(s,"\t");
			int l=st.countTokens();
			String[] a=new String[l];
			for(int j=0;j<l;j++)
			{
				a[j]=st.nextToken();
			}
			wr=f.searchpot(a);
			if(wr!=null)
				out.write(wr+"\n");
			s=in.readLine();
		}
		in.close();
		out.close();
		f.writest();
		f.writelt();
	}
}