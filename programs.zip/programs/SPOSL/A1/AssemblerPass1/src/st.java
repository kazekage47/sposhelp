
public class st {
	String sname;
	int value;
	int address;
	int length;
	int relocation;
	st()
	{
		sname = null;
		value = 0;
		address = 0;
		length = 0;
		relocation = 0;
	}
	public void displayst()
	{
		System.out.println(sname+"\t"+address+"\t"+value+"\t"+length+"\t"+relocation);
	}
	public void entryst(String n, int a, int v, int l, int r)
	{
		sname = n;
		value = v;
		address = a;
		length = l;
		relocation = r;
	}
	public boolean equalst(String label)
	{
		if(sname.equals(label))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	public String getst() {
		String gst;
		gst=sname+" "+address+" "+value+" "+length+" "+relocation;
		return gst;
	}
}