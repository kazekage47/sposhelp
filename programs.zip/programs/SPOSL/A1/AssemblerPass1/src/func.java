import java.io.*;
import java.util.*;
public class func {
	int lflag=0;
	ArrayList<st> s = new ArrayList<st>();
	ArrayList<lt> l = new ArrayList<lt>();
	int lc=0,pos=0,posl=0;
	public String searchpot(String as[]) throws Exception {
		String ret=null;
		int p=0;
		if(as.length==3)
			p=1;
		switch(as[p])
		{
		case "START":
			Start(as);
			break;
		case "USING":
			return (Integer.toString(lc)+" "+as[0]+" "+as[1]);
		case "LTORG":
			ret=LTORG(0);
			break;
		case "DC":
			ret=DC(as);
			break;
		case "DS":
			ret=DS(as);
			break;
		case "END":
			ret=LTORG(1);
			if(ret!=null)
			{
				ret="\n"+lc+" "+"END";
			}
			else
				ret=lc+" "+"END";
			break;
		default:
			ret=searchmot(as);
		}
		return ret;
	}
	public void Start(String a[]) throws Exception {
		if(a[0].equals("START"))
		{
			if(a.length==1)
				lc=0;
			else
				lc=Integer.parseInt(a[1]);
		}
		else
		{
			if(a.length==2)
				lc=0;
			else
			{
				lc=Integer.parseInt(a[2]);
				st ast = new st();
				ast.entryst(a[0], lc, 0, 1, 1);
				s.add(ast);
				pos++;
			}
		}
	}
	public String DC(String ac[]) throws Exception {
		String retdc=null;
		int l=0;
		StringTokenizer stdc = new StringTokenizer(ac[2],"'");
		if(stdc.nextToken().equals("F"))
			l=4;
		else
			l=2;
		int val=Integer.parseInt(stdc.nextToken());
		int flag=checkst(ac[0]);
		if(flag==-1)
		{
			st ele = new st();
			ele.entryst(ac[0], lc, val, l, 1);
			s.add(ele);
			pos++;
		}
		else
		{
			s.get(flag).entryst(ac[0], lc, val, l, 1);
		}
		retdc=lc+" "+val;
		lc=lc+l;
		return retdc;
	}
	public String DS(String ads[]) throws Exception {
		String retds=null;
		int l=0;
		String token;
		if(ads[2].endsWith("F"))
		{
			token="F";
			l=4;
		}
		else
		{
			token="H";
			l=2;
		}
		StringTokenizer stds=new StringTokenizer(ads[2],token);
		int n = Integer.parseInt(stds.nextToken());
		l=l*n;
		int flag=checkst(ads[0]);
		if(flag==-1)
		{
			st ele = new st();
			ele.entryst(ads[0], lc, 0, l, 1);
			s.add(ele);
			pos++;
		}
		else
		{
			s.get(flag).entryst(ads[0], lc, 0, l, 1);
		}
		retds=lc+" ?"+ads[0];
		lc=lc+l;
		return retds;
	}
	public int checkst(String name) throws Exception {
		for(int i=0;i<pos;i++)
		{
			if(s.get(i).equalst(name))
				return i;
		}
		return -1;
	}
	public String searchmot(String am[]) throws Exception {
		String retm=null;
		BufferedReader inmot = new BufferedReader(new InputStreamReader(new FileInputStream("/home/akshit/workspace/Pass1/src/mot.txt")));
		String m=inmot.readLine();
		String name=null;
		int lm=0,flag=0;
		while(m!=null)
		{
			if(m.startsWith(am[0]))
			{
				StringTokenizer stm=new StringTokenizer(m," ");
				name=stm.nextToken();
				stm.nextToken();
				lm=Integer.parseInt(stm.nextToken());
				flag=1;
				break;
			}
			m=inmot.readLine();
		}
		inmot.close();
		if(flag==1)
		{
			retm=lc+" "+name+" "+am[1];
			lc=lc+lm;
			if(!name.endsWith("R"))
				processoperand(am[1],lm);
		}
		return retm;
	}
	public String LTORG(int k) throws Exception {
		String retl=null;
		for(int i=0;i<posl;i++)
		{
			if(l.get(i).address==-1)
			{
				if(k==0 && lflag==0)
				{
					retl=lc+" -\n";
					while(lc%8!=0)
						lc++;
				}
				lflag=1;
				String namel=l.get(i).lname;
				StringTokenizer lto=new StringTokenizer(namel,"'");
				int len=0;
				if(lto.nextToken().startsWith("=F"))
					len=4;
				else
					len=2;
				int val=Integer.parseInt(lto.nextToken());
				l.get(i).entrylt(namel, lc, val, len, 1);
				retl=retl+lc+" "+val;
				lc=lc+len;
			}
		}
		return retl;
	}
	public void processoperand(String po, int lo) throws Exception {
		StringTokenizer stpo = new StringTokenizer(po,",");
		stpo.nextToken();
		String var=stpo.nextToken();
		if(!var.startsWith("="))
		{
			int flag=checkst(var);
			if(flag==-1)
			{
				st ele = new st();
				ele.entryst(var, -1, -1, lo, 1);
				s.add(ele);
				pos++;
			}
			else
			{
				s.get(flag).entryst(var, -1, -1, lo, 1);
			}
		}
		else
		{
			int flag=checklt(var);
			if(flag==-1)
			{
				lt elel = new lt();
				elel.entrylt(var, -1, -1, -1, 1);
				l.add(elel);
				posl++;
			}
		}
	}
	public int checklt(String name) throws Exception {
		for(int i=0;i<posl;i++)
		{
			if(l.get(i).equallt(name))
				return i;
		}
		return -1;
	}
	public void displaytables() throws Exception {
		System.out.println("Symbol Table");
		for(int i=0;i<pos;i++)
		{
			s.get(i).displayst();
		}
		System.out.println("\nLiteral Table\n");
		for(int i=0;i<posl;i++)
		{
			l.get(i).displaylt();
		}
	}
	public void writest() throws Exception {
		FileWriter fwst = new FileWriter("src/st.txt",true);
	    BufferedWriter bwst = new BufferedWriter(fwst);
	    PrintWriter outst = new PrintWriter(bwst);
	    String wst;
	    for(int i=0;i<pos;i++)
	    {
	    	wst=s.get(i).getst();
	    	outst.write(wst+"\n");
	    }
	    outst.close();
	}
	public void writelt() throws Exception {
		FileWriter fwlt = new FileWriter("src/lt.txt",true);
	    BufferedWriter bwlt = new BufferedWriter(fwlt);
	    PrintWriter outlt = new PrintWriter(bwlt);
	    String wst;
	    for(int i=0;i<posl;i++)
	    {
	    	wst=l.get(i).getlt();
	    	outlt.write(wst+"\n");
	    }
	    outlt.close();
	}
}