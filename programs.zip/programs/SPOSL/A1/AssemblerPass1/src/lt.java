
public class lt {
	String lname;
	int address;
	int value;
	int length;
	int relocation;
	lt()
	{
		lname=null;
		address=0;
		value=0;
		length=0;
		relocation=0;
	}
	public void displaylt()
	{
		System.out.println(lname+"\t"+address+"\t"+value+"\t"+length+"\t"+relocation);
	}
	public void entrylt(String n, int a, int v, int l, int r)
	{
		lname = n;
		value = v;
		address = a;
		length = l;
		relocation = r;
	}
	public boolean equallt(String label)
	{
		if(lname.equals(label))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	public String getlt() {
		String glt;
		glt=lname+" "+address+" "+value+" "+length+" "+relocation;
		return glt;
	}
}
