import java.io.*;
import java.util.*;
public class hello {
	
	public native float add(float a, float b);
	public native float sub(float a, float b);
	public native float mult(float a, float b);
	public native float div(float a, float b);
	public native float sine(float a);
	public native float factorial(float a);
	
	static{
		System.loadLibrary("testlib");
	}
	
	public static void main(String args[]) {
		Scanner in = new Scanner(System.in);
		System.out.println("\n\t1.Add\n\t2.Subtract\n\t3.Multiply\n\t4.Divide\n\t5.Sine\n\t6.Factorial\nEnter choice: ");
		int choice = in.nextInt();
		float a=0,b=0;
		if (choice<5)
		{
			System.out.println("Enter two numbers: ");
			a = in.nextFloat();
			b = in.nextFloat();
		}
		else
		{
			System.out.println("Enter a number: ");
			a = in.nextFloat();
		}
		switch(choice)
		{
			case 1:
				System.out.println(new hello().add(a,b));
				break;
			case 2:
				System.out.println(new hello().sub(a,b));
				break;
			case 3:
				System.out.println(new hello().mult(a,b));
				break;
			case 4:
				System.out.println(new hello().div(a,b));
				break;
			case 5:
				System.out.println(new hello().sine(a));
				break;
			case 6:
				System.out.println(new hello().factorial(a));
				break;
			default:
				System.out.println("Invalid input");
		}
	}
}

/*

javah -jni hello
hello.h file is created

locate jni.h and jni_md.h

gcc -I /usr/lib/jvm/java-1.7.0-openjdk-1.7.0.60-2.4.3.0.fc20.x86_64/include/ -I /usr/lib/jvm/java-1.7.0-openjdk-1.7.0.60-2.4.3.0.fc20.x86_64/include/linux/ -shared -o libtestlib.so test.c

javac hello.java
java -Djava.library.path=. hello
*/
