#include<jni.h>
#include"hello.h"
#include<math.h>
JNIEXPORT jfloat JNICALL Java_hello_add (JNIEnv *env, jobject obj, jfloat a, jfloat b)
{
	return a+b;
}
JNIEXPORT jfloat JNICALL Java_hello_mult (JNIEnv *env, jobject obj, jfloat a, jfloat b)
{
	return a*b;
}
JNIEXPORT jfloat JNICALL Java_hello_sub (JNIEnv *env, jobject obj, jfloat a, jfloat b)
{
	return a-b;
}
JNIEXPORT jfloat JNICALL Java_hello_div (JNIEnv *env, jobject obj, jfloat a, jfloat b)
{
	return a/b;
}
JNIEXPORT jfloat JNICALL Java_hello_sine(JNIEnv *env, jobject obj, jfloat a)
{
	return sin(a);
}
JNIEXPORT jfloat JNICALL Java_hello_factorial (JNIEnv *env, jobject obj, jfloat a)
{
	float i = 1;
	float ans=1;
	for(;i<=a;i++)
		ans = ans * i;
	return ans;
}
