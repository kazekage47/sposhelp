import java.io.*;
public class mnt {
	int index;
	String name;
	int mdtindex;
	mnt()
	{
		index=0;
		mdtindex=0;
		name=null;
	}
	public void entrymnt(int i, String n, int mi) throws Exception {
		index=i;
		name=n;
		mdtindex=mi;
	}
	public String write() throws Exception {
		return (index+" "+name+" "+mdtindex);
	}
}
