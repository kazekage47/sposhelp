import java.io.*;
import java.util.*;
public class pass1 {
	static ArrayList<mnt> n = new ArrayList<mnt>();
	static ArrayList<mdt> d = new ArrayList<mdt>();
	static ArrayList<ala> a = new ArrayList<ala>();
	static int mnti=1,mdti=1,alai=0;
	public static void main(String args[]) throws Exception {
		/*
		 * Change file paths before execution.
		 */
		BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("/root/Documents/TE Sem II/SPOSL/InProgress/MacroPass1/src/in.asm")));
		FileWriter fw = new FileWriter("src/out.txt",true);
	    BufferedWriter bw = new BufferedWriter(fw);
	    PrintWriter out = new PrintWriter(bw);
		String s;
		s=in.readLine();
		while(s!=null)
		{
			if(s.equals("MACRO"))
			{
				s=in.readLine();
				StringTokenizer st = new StringTokenizer(s," ");
				String name = st.nextToken();
				mnt m = new mnt();
				m.entrymnt(mnti, name, mdti);
				mnti++;
				n.add(m);
				StringTokenizer st2 = new StringTokenizer(st.nextToken(),",");
				int l=st2.countTokens();
				for(int i=0;i<l;i++)
				{
					ala al = new ala();
					al.entryarg(alai, st2.nextToken());
					alai++;
					a.add(al);
				}
				mdt md = new mdt();
				md.entrymdt(mdti, s);
				mdti++;
				d.add(md);
				s=in.readLine();
				while(!s.equals("MEND"))
				{
					StringTokenizer st3 = new StringTokenizer(s," ");
					String n=st3.nextToken();
					StringTokenizer st4 = new StringTokenizer(st3.nextToken(),",");
					String[] aa = new String[2];
					aa[0]=st4.nextToken();
					aa[1]=st4.nextToken();
					for(int j=0;j<2;j++)
					{
						if(aa[j].startsWith("&"))
						{
							int flag=-1;
							for(int i=0;i<alai;i++)
							{
								flag=a.get(i).searchala(aa[j]);
								if(flag!=-1)
								{
									aa[j]="#"+Integer.toString(flag);
									break;
								}
							}
						}
					}
					mdt md1 = new mdt();
					md1.entrymdt(mdti, n+" "+aa[0]+","+aa[1]);
					mdti++;
					d.add(md1);
					s=in.readLine();
				}
				mdt md2 = new mdt();
				md2.entrymdt(mdti, s);
				mdti++;
				d.add(md2);
				s=in.readLine();
			}
			if(!s.equals("MACRO"))
			{
				out.write(s+"\n");
				s=in.readLine();
			}
		}
		for(int x=0;x<alai;x++)
		{
			FileWriter fw1 = new FileWriter("src/ala.txt",true);
		    BufferedWriter bw1 = new BufferedWriter(fw1);
		    PrintWriter out1 = new PrintWriter(bw1);
		    out1.write(a.get(x).write()+"\n");
		    out1.close();
		}
		for(int y=0;y<mnti-1;y++)
		{
			FileWriter fw2 = new FileWriter("src/mnt.txt",true);
		    BufferedWriter bw2 = new BufferedWriter(fw2);
		    PrintWriter out2 = new PrintWriter(bw2);
		    out2.write(n.get(y).write()+"\n");
		    out2.close();
		}
		for(int z=0;z<mdti-1;z++)
		{
			FileWriter fw3 = new FileWriter("src/mdt.txt",true);
		    BufferedWriter bw3 = new BufferedWriter(fw3);
		    PrintWriter out3 = new PrintWriter(bw3);
		    out3.write(d.get(z).write()+"\n");
		    out3.close();
		}
		in.close();
		out.close();
	}	
}
