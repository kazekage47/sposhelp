import java.io.*;
public class mdt {
	int index;
	String def;
	mdt()
	{
		index=0;
		def=null;
	}
	public void entrymdt(int i, String d) throws Exception {
		index=i;
		def=d;
	}
	public String write() throws Exception {
		return (index+" "+def);
	}
}