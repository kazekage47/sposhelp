import java.io.*;
public class ala {
	int index;
	String arg;
	ala()
	{
		index=0;
		arg=null;
	}
	public void entryarg(int i, String a) throws Exception {
		index=i;
		arg=a;
	}
	public int searchala(String a) throws Exception {
		if(arg.equals(a))
			return index;
		else
			return -1;
	}
	public String write() throws Exception {
		return (index+" "+arg);
	}
}
