import java.io.*;
import java.util.*;
public class pass2 {
	public static void main(String args[]) throws Exception {
		/*
		 * Change file paths before execution.
		 */
		BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("/root/Documents/SPOSL/InProgress/MacroPass2/src/in.asm")));
		String s = in.readLine();
		FileWriter fw = new FileWriter("src/out.txt",true);
	    BufferedWriter bw = new BufferedWriter(fw);
	    PrintWriter out = new PrintWriter(bw);
		ala[] al = new ala[20];
		BufferedReader inala = new BufferedReader(new InputStreamReader(new FileInputStream("/root/Documents/SPOSL/InProgress/MacroPass2/src/ala.txt")));
		String aa = inala.readLine();
		int alacounter = 0;
		while(aa!=null)
		{
			al[alacounter] = new ala();
			StringTokenizer as1 = new StringTokenizer(aa," ");
			al[alacounter].createala(Integer.parseInt(as1.nextToken()),as1.nextToken());
			alacounter++;
			aa = inala.readLine();
		}
		inala.close();
		int flag = 0;
		while(s!=null)
		{
			flag = 0;
			BufferedReader inmnt = new BufferedReader(new InputStreamReader(new FileInputStream("/root/Documents/SPOSL/InProgress/MacroPass2/src/mnt.txt")));
			BufferedReader inmdt = new BufferedReader(new InputStreamReader(new FileInputStream("/root/Documents/SPOSL/InProgress/MacroPass2/src/mdt.txt")));
			String sn = inmnt.readLine();
			while(sn!=null)
			{
				StringTokenizer st = new StringTokenizer(sn," ");
				st.nextToken();
				String n = st.nextToken();
				int di = Integer.parseInt(st.nextToken());
				if(s.startsWith(n))
				{
					StringTokenizer st1 = new StringTokenizer(s," ");
					st1.nextToken();
					StringTokenizer st2 = new StringTokenizer(st1.nextToken(),",");
					int l = st2.countTokens();
					String[] a = new String[l];
					for(int i=0;i<l;i++)
					{
						a[i]=st2.nextToken();
					}
					String sd = inmdt.readLine();
					while(sd!=null)
					{
						if(sd.startsWith(Integer.toString(di)))
						{
							flag = 1;
							StringTokenizer sd1 = new StringTokenizer(sd," ");
							sd1.nextToken();
							sd1.nextToken();
							StringTokenizer sd2 = new StringTokenizer(sd1.nextToken(),",");
							int ll = sd2.countTokens();
							if(l!=ll)
							{
								System.out.println("Macro arguments do not match, program terminated.");
								System.exit(0);
							}
							String[] b = new String[ll];
							for(int i=0;i<ll;i++)
							{
								b[i]=sd2.nextToken();
							}
							for(int i=0;i<ll;i++)
							{
								for(int j=0;j<alacounter;j++)
								{
									if(al[j].search(b[i]))
									{
										al[j].editala(a[i]);
										break;
									}
								}
							}
							sd = inmdt.readLine();
							while(!sd.contains("MEND"))
							{
								StringTokenizer sd3 = new StringTokenizer(sd," ");
								sd3.nextToken();
								out.write(sd3.nextToken()+" ");
								StringTokenizer sd4 = new StringTokenizer(sd3.nextToken(),",");
								out.write(sd4.nextToken()+"'");
								StringTokenizer sd5 = new StringTokenizer(sd4.nextToken(),"#");
								out.write(al[Integer.parseInt(sd5.nextToken())].getarg()+"\n");
								sd = inmdt.readLine();
							}
						}
						sd=inmdt.readLine();
					}
					break;
				}
				sn = inmnt.readLine();
			}
			inmnt.close();
			inmdt.close();
			if(flag == 0)
				out.write(s+"\n");
			s=in.readLine();
		}
		in.close();
		out.close();
	}
}
