
public class ala {
	int index;
	String value;
	ala()
	{
		index = -1;
		value = null;
	}
	public void createala(int i, String v)
	{
		index = i;
		value = v;
	}
	public boolean search(String v)
	{
		if(value.equals(v))
			return true;
		else
			return false;
	}
	public void editala(String v)
	{
		value = v;
	}
	public void displayala()
	{
		System.out.println(index+" "+value);
	}
	public String getarg()
	{
		return value;
	}
}
