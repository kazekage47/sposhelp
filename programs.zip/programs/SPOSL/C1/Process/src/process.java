public class process {
	String pid;
	int at;
	int bt;
	int wt;
	int ft;
	int tt;
	int st;
	int pt;
	process()
	{
		pid="null";
		at=0;
		bt=0;
		wt=0;
		ft=0;
		tt=0;
		st=0;
		pt=0;
	}
	public void setprocess(String p, int a, int b, int s, int w, int f, int t, int pr)
	{
		pid=p;
		at=a;
		bt=b;
		wt=w;
		ft=f;
		tt=t;
		st=s;
		pt=pr;
	}
	public void display()
	{
		System.out.println(pid+" "+at+" "+bt+" "+pt);
	}
	public void displayfull()
	{
		System.out.println(pid+" "+at+" "+bt+" "+st+" "+wt+" "+ft+" "+tt+" "+pt);
	}
	public String getpid()
	{
		return pid;
	}
	public int getat()
	{
		return at;
	}
	public int getbt()
	{
		return bt;
	}
	public int getwt()
	{
		return wt;
	}
	public int gettt()
	{
		return tt;
	}
}
