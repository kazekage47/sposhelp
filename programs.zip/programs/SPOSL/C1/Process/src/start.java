import java.io.*;
public class start {
	public static void main(String args[]) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the number of process: ");
		int total = Integer.parseInt(br.readLine());
		process pr[] = new process[total];
		process dup[] = new process[total];
		String prid;
		int a,b,p;
		for(int i=0;i<total;i++)
		{
			System.out.println("Enter process ID: ");
			prid = br.readLine();
			System.out.println("Enter arrival time: ");
			a = Integer.parseInt(br.readLine());
			System.out.println("Enter burst time: ");
			b = Integer.parseInt(br.readLine());
			System.out.println("Enter priority: ");
			p = Integer.parseInt(br.readLine());
			pr[i] = new process();
			pr[i].setprocess(prid , a, b, 0, 0, 0, 0, p);
		}
		//sorting start
        for (int i = 0; i < total-1; i++)
        {
            for (int j = 0; j < total-i-1; j++)
                if (pr[j].getat() > pr[j+1].getat())
                {
                    process temp = pr[j];
                    pr[j] = pr[j+1];
                    pr[j+1] = temp;
                }
        }
        
        for(int i=0;i<total;i++)
        {
        	pr[i].display();
        }
        System.out.println("\n\n");
        //sorting end
        while(true)
        {
        //SWITCH START
        System.out.println("\n\n\t1.FCFS\n\t2.SJF\n\t3.RR\n\t4.Priority(P)\n\t5.Priority(NP)\n\t6.Exit\nEnter your choice: ");
        int choice = Integer.parseInt(br.readLine());
        switch(choice)
        {
        case 1:
        	//first come first serve code start
    		String pid;
            int ct = 0,st,bt,at,ft,wt,tt;
            for(int i=0;i<total;i++)
    		{
    			if(ct>=pr[i].getat())
    			{
    				pid = pr[i].getpid();
    				at = pr[i].getat();
    				bt = pr[i].getbt();
    				st=ct;
    				System.out.println("Process "+pid+" is started at "+ct+".");
    				ct = ct + bt;
    				ft = ct;
    				wt = st - at;
    				tt = wt + bt;
    				pr[i].setprocess(pid, at, bt, st, wt, ft, tt, 0);
    			}
    			else
    			{
    				ct++;
    				i--;
    			}
    		}
            System.out.println("\n\n");
    		//first come first serve code end
            System.out.println("PID-AT-BT-ST-WT-FT-TT-PT");
            for(int i=0;i<total;i++)
            {
            	pr[i].displayfull();
            }
            float avg=0,avgt=0;
            for(int i=0;i<total;i++)
            {
            	avg+=pr[i].getwt();
            	avgt+=pr[i].gettt();
            }
            avg = avg/total;
            avgt = avgt/total;
            System.out.println("\nAverage Waiting time: "+avg+".");
            System.out.println("\nAverage Turn Around time: "+avgt+".");
        	//DISPLAY
            System.out.println("\n");
            for(int i=0;i<total;i++)
            {
            	System.out.print(pr[i].getpid()+"\t");
            	for(int j=0;j<pr[i].ft;j++)
            	{
            		if(j>=pr[i].st)
            			System.out.print("-");
            		else
            			System.out.print(" ");
            	}
            	System.out.print("\n");
            }
            break;
        case 2:
        	int currt=0,mat=9999,count=0;
        	while(true)
        	{
	        	//adding the processes in current table
	        	for(int i=0;i<total;i++)
	        	{
	        		if(currt==pr[i].at)
	        		{
	        			dup[i] = new process();
	        			dup[i].setprocess(pr[i].pid, pr[i].at, pr[i].bt, 0, 0, 0, 0, 0);
	        			count++;
	        		}
	        	}
	        	//checking for the shortest burst time
	        	int mpid=0;
	        	mat=9999;
	        	for(int j=0;j<count;j++)
	        	{
	        		if(dup[j].bt<mat && dup[j].bt>0)
	        		{
	        			mat = dup[j].bt;
	        			mpid = j;
	        		}
	        	}
	        	if(mat==9999)
	        		break;
	        	if(dup[mpid].bt==pr[mpid].bt)
	        	{
	        		pr[mpid].st=currt;
	        	}
	        	if(dup[mpid].bt==1)
	        	{
	        		pr[mpid].ft=currt+1;
	        	}
	        	//processing shortest job first preemptive
	        	System.out.println("Process "+dup[mpid].getpid()+" is started at "+currt+" and burst time left= "+dup[mpid].bt);
	        	currt++;
	        	dup[mpid].bt--;
        	}
        	//average waiting and turn around time calculation
        	float avgw=0,avgtt=0;
        	for(int i=0;i<total;i++)
        	{
        		pr[i].tt = pr[i].ft - pr[i].at;
        		pr[i].wt = pr[i].tt - pr[i].bt;
        	}
        	System.out.println("PID-AT-BT-ST-WT-FT-TT-PT");
            for(int i=0;i<total;i++)
            {
            	pr[i].displayfull();
            	avgw+=pr[i].wt;
            	avgtt+=pr[i].tt;
            }
            avgw = avgw/total;
            avgtt = avgtt/total;
            System.out.println("Average waiting time: "+avgw);
            System.out.println("Average turn around time: "+avgtt);
        	break;
        case 3:
        	//Round Robin
        	int tq=0,t=0,counter=0,acount=0,pointer=0,scount=0;
        	int burst[] = new int[200];
        	String proc[] = new String[200];
        	System.out.println("Enter the time quantum: ");
        	tq = Integer.parseInt(br.readLine());
        	for(int i=acount;i<total;i++)
        	{
        		if(t>=pr[i].at)
        		{
        			proc[counter] = pr[i].pid;
        			burst[counter] = pr[i].bt;
        			counter++;
        			acount++;
        		}
        		else
        		{
        			break;
        		}
        	}
        	while(true)
        	{
        		for(int i=scount;i<acount;i++)
        		{
        			if(pr[i].pid==proc[pointer] && burst[pointer]==pr[i].bt)
        			{
        				pr[i].st=t;
        				scount++;
        			}
        		}
        		System.out.println("Process "+proc[pointer]+" executing at time "+t+" with remaining burst time "+burst[pointer]+".");
        		if(burst[pointer]-tq<0)
        		{
        			t+=burst[pointer];
        			burst[pointer]=0;
        		}
        		else
        		{
        			burst[pointer]-=tq;
        			t+=tq;
        		}
        		for(int i=acount;i<total;i++)
            	{
            		if(t>=pr[i].at)
            		{
            			proc[counter] = pr[i].pid;
            			burst[counter] = pr[i].bt;
            			counter++;
            			acount++;
            		}
            		else
            		{
            			break;
            		}
            	}
        		if(burst[pointer]!=0)
        		{
        			proc[counter]=proc[pointer];
        			burst[counter]=burst[pointer];
        			pointer++;
        			counter++;
        		}
        		else
        		{
        			for(int i=0;i<acount;i++)
        			{
        				if(pr[i].pid==proc[pointer])
        				{
        					pr[i].ft=t;
        				}
        			}
        			pointer++;
        		}
        		if(pointer==counter)
        		{
        			break;
        		}
        	}
        	for(int i=0;i<total;i++)
        	{
        		pr[i].tt = pr[i].ft - pr[i].at;
        		pr[i].wt = pr[i].tt - pr[i].bt;
        	}
        	float avgrw = 0, avgrt = 0;
        	System.out.println("PID-AT-BT-ST-WT-FT-TT-PT");
            for(int i=0;i<total;i++)
            {
            	pr[i].displayfull();
            	avgrw+=pr[i].wt;
            	avgrt+=pr[i].tt;
            }
            avgrw = avgrw/total;
            avgrt = avgrt/total;
            System.out.println("Average waiting time: "+avgrw);
            System.out.println("Average turn around time: "+avgrt);
        	break;
        case 4:
        	int curt=0,mpt=9999,cnt=0;
        	while(true)
        	{
	        	//adding the processes in current table
	        	for(int i=0;i<total;i++)
	        	{
	        		if(curt==pr[i].at)
	        		{
	        			dup[i] = new process();
	        			dup[i].setprocess(pr[i].pid, pr[i].at, pr[i].bt, 0, 0, 0, 0, pr[i].pt);
	        			cnt++;
	        		}
	        	}
	        	//checking for the highest priority i.e. least integer value
	        	int m=0;
	        	mpt=9999;
	        	for(int j=0;j<cnt;j++)
	        	{
	        		if(dup[j].bt<mpt && dup[j].bt>0)
	        		{
	        			mpt = dup[j].pt;
	        			m = j;
	        		}
	        	}
	        	if(mpt==9999)
	        		break;
	        	if(dup[m].bt==pr[m].bt)
	        	{
	        		pr[m].st=curt;
	        	}
	        	if(dup[m].bt==1)
	        	{
	        		pr[m].ft=curt+1;
	        	}
	        	//processing priority preemptive
	        	System.out.println("Process "+dup[m].getpid()+" is started at "+curt+", burst time left= "+dup[m].bt+" and priority= "+dup[m].pt);
	        	curt++;
	        	dup[m].bt--;
        	}
        	//average waiting and turn around time calculation
        	float avgpw=0,avgptt=0;
        	for(int i=0;i<total;i++)
        	{
        		pr[i].tt = pr[i].ft - pr[i].at;
        		pr[i].wt = pr[i].tt - pr[i].bt;
        	}
        	System.out.println("PID-AT-BT-ST-WT-FT-TT-PT");
            for(int i=0;i<total;i++)
            {
            	pr[i].displayfull();
            	avgpw+=pr[i].wt;
            	avgptt+=pr[i].tt;
            }
            avgpw = avgpw/total;
            avgptt = avgptt/total;
            System.out.println("Average waiting time: "+avgpw);
            System.out.println("Average turn around time: "+avgptt);
        	break;
        case 5:
        	int crt=0,mpr=9999,cntp=0;
        	while(true)
        	{
	        	//adding the processes in current table
	        	for(int i=cntp;i<total;i++)
	        	{
	        		if(crt>=pr[i].at)
	        		{
	        			dup[i] = new process();
	        			dup[i].setprocess(pr[i].pid, pr[i].at, pr[i].bt, 0, 0, 0, 0, pr[i].pt);
	        			cntp++;
	        		}
	        	}
	        	//checking for the highest priority i.e. least integer value
	        	int m=0;
	        	mpr=9999;
	        	for(int j=0;j<cntp;j++)
	        	{
	        		if(dup[j].pt<mpr && dup[j].bt>0)
	        		{
	        			mpr = dup[j].pt;
	        			m = j;
	        		}
	        	}
	        	if(mpr==9999)
	        		break;
	        	pr[m].st=crt;
	        	pr[m].ft=crt+pr[m].bt;
	        	//processing priority non-preemptive
	        	System.out.println("Process "+dup[m].getpid()+" is started at "+crt+", burst time left= "+dup[m].bt+" and priority= "+dup[m].pt);
	        	crt+=dup[m].bt;
	        	dup[m].bt=0;
        	}
        	//average waiting and turn around time calculation
        	float avgnpw=0,avgnptt=0;
        	for(int i=0;i<total;i++)
        	{
        		pr[i].tt = pr[i].ft - pr[i].at;
        		pr[i].wt = pr[i].tt - pr[i].bt;
        	}
        	System.out.println("PID-AT-BT-ST-WT-FT-TT-PT");
            for(int i=0;i<total;i++)
            {
            	pr[i].displayfull();
            	avgnpw+=pr[i].wt;
            	avgnptt+=pr[i].tt;
            }
            avgnpw = avgnpw/total;
            avgnptt = avgnptt/total;
            System.out.println("Average waiting time: "+avgnpw);
            System.out.println("Average turn around time: "+avgnptt);
        	break;
        case 6:
        	System.exit(0);
        default:
        	System.out.println("Invalid Input");
        }
        //SWITCH END
        }
	}
}