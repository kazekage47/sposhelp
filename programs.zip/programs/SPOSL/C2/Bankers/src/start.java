import java.io.*;
import java.util.*;
public class start {
	public static void main(String args[]) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int n=0,m=0;
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the number of processes: ");
		n = Integer.parseInt(br.readLine());
		System.out.print("Enter the number of resources: ");
		m = Integer.parseInt(br.readLine());
		int[][] claim = new int[n][m];
		int[][] allocr = new int[n][m];
		int[][] alloc = new int[n][m];
		int[][] need = new int[n][m];
		int[][] needd = new int[n][m];
		int[] curr = new int[m];
		int[] currr = new int[m];
		int[] available = new int[m];
		String[] seq = new String[n];
		int[] process = new int[n];
		int scount = 0;
		System.out.println("Enter the available instances of the following resources.");
		for(int i=0;i<m;i++)
		{
			System.out.print("Instances of Resource "+i+": ");
			available[i]=sc.nextInt();
			curr[i]=available[i];
			currr[i]=available[i];
		}
		System.out.println("Enter the claim for each process in the following manner.\nResource 1 <space> Resource 2 <space> ... Resource n <enter>");
		for(int i=0;i<n;i++)
		{
			System.out.print("Process "+i+": ");
			for(int j=0;j<m;j++)
			{
				claim[i][j]=sc.nextInt();
			}
		}
		System.out.println("Enter the allocated resources for each process in the following manner.\nResource 1 <space> Resource 2 <space> ... Resource n <enter>");
		for(int i=0;i<n;i++)
		{
			System.out.print("Process "+i+": ");
			for(int j=0;j<m;j++)
			{
				allocr[i][j]=sc.nextInt();
				alloc[i][j]=allocr[i][j];
			}
		}
		//calculation of need matrix
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<m;j++)
			{
				need[i][j]=claim[i][j]-alloc[i][j];
				needd[i][j]=need[i][j];
			}
		}
		//verification process
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<m;j++)
			{
				if((need[i][j]+alloc[i][j])<=available[j])
				{
					curr[j]-=alloc[i][j];
					currr[j]-=alloc[i][j];
				}
				else
				{
					System.out.println("Error: Resources not available.");
					System.exit(0);
				}
			}
		}
		for(int i=0;i<m;i++)
		{
			System.out.print(curr[i]);
		}
		//bankers algorithm in switch statement
		int flag,eflag;
		while(true)
		{
			System.out.println("\n\t1.Safety.\n\t2.Request Safety.\n\t3.Exit.\n\n\tEnter choice preference: ");
			int choice = sc.nextInt();
			switch(choice)
			{
			case 1:
				//safety check
			while(true)
			{
				eflag=0;//loop termination flag, terminates if eflag == 0
				for(int i=0;i<n;i++)
				{
					for(int j=0;j<n;j++)
					{
						process[j]=0;
					}
					for(int j=0;j<m;j++)
					{
						process[i]+=need[i][j];
					}
					//
					if(!(process[i]==0 && searchseq(seq,"P"+i,n)))
					{
						flag=0;//flag to execute a process, executes if flag==0
						for(int j=0;j<m;j++)
						{
							if(!(need[i][j]<=curr[j]))
							{
								flag=1;//here one indicates not executable
							}
						}
						if(flag==0)//will run only if process can be executed
						{
							seq[scount] = "P"+i;
							scount++;
							for(int j=0;j<m;j++)
							{
								curr[j]+=alloc[i][j];
								need[i][j]=0;
								alloc[i][j]=0;
							}
							eflag=1;//process is executed
						}
					}
				}
				if(eflag==0)
				{
					break;
				}
			}
			if(scount==n)
			{
				System.out.print("\nCurrent state is safe.\n\tExecution sequence:");
				for(int i=0;i<n;i++)
				{
					System.out.print(" "+seq[i]+" ");
				}
			}
			else
				System.out.println("\nCurrent state is not safe.\n");
				break;
			case 2:
				scount=0;
				int pn;
				int[] pr = new int[m];
				System.out.println("Request from process number: ");
				pn=sc.nextInt();
				System.out.println("Enter the resources separated with spaces: ");
				for(int i=0;i<m;i++)
				{
					pr[i]=sc.nextInt();
				}
				for(int i=0;i<m;i++)
				{
					allocr[pn][i]+=pr[i];
					needd[pn][i]-=pr[i];
					currr[i]-=pr[i];
				}
				//safety check
				while(true)
				{
					eflag=0;//loop termination flag, terminates if eflag == 0
					for(int i=0;i<n;i++)
					{
						for(int j=0;j<n;j++)
						{
							process[j]=0;
						}
						for(int j=0;j<m;j++)
						{
							process[i]+=needd[i][j];
						}
						//
						if(!(process[i]==0 && searchseq(seq,"P"+i,n)))
						{
							flag=0;//flag to execute a process, executes if flag==0
							for(int j=0;j<m;j++)
							{
								if(!(needd[i][j]<=currr[j]))
								{
									flag=1;//here one indicates not executable
								}
							}
							if(flag==0)//will run only if process can be executed
							{
								seq[scount] = "P"+i;
								scount++;
								for(int j=0;j<m;j++)
								{
									currr[j]+=allocr[i][j];
									needd[i][j]=0;
									allocr[i][j]=0;
								}
								eflag=1;//process is executed
							}
						}
					}
					if(eflag==0)
					{
						break;
					}
				}
				if(scount==n)
				{
					System.out.print("\nCurrent state is safe.\n\tExecution sequence:");
					for(int i=0;i<n;i++)
					{
						System.out.print(" "+seq[i]+" ");
					}
				}
				else
					System.out.println("\nCurrent state is not safe.\n");
				break;
			case 3:
				System.exit(0);
			default:
				System.out.println("Invalid input.");
			}
		}
	}
	public static boolean searchseq(String[] seq,String key,int n)
	{
		for(int i=0;i<n;i++)
		{
			if(seq[i]==null)
				return false;
			if(seq[i].equals(key))
				return true;
		}
		return false;
	}
}