import java.io.*;
import java.awt.*;

class input {
int a=10,b=15,c;
public static void main(String args[]) {
	System.out.println("Hello world");
	}
	/*
	Multi
	line*
	comment
	*/
	void add()
	{
	c = a+b; //Addition of two numbers
	System.out.println(c);
	}
}
