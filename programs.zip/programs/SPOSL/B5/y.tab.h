#define Verb 257
#define Noun 258
#define Conj 259
#define N 260
