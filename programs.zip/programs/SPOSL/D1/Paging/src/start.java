import java.io.*;
import java.util.*;
public class start {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of instances of pages: ");
		int m;
		m=sc.nextInt();
		int[] pg = new int[m];
		System.out.println("Enter the instances of pages with spaces in between: ");
		for(int i=0;i<m;i++)
		{
			pg[i]=sc.nextInt();
		}
		System.out.println("Enter the frame size: ");
		int size = sc.nextInt();
		int[] frame = new int[size];
		while(true)
		{
			for(int i=0;i<size;i++)
			{
				frame[i]=-1;
			}
			int choice,ff=0,ffl=0,ffo=0;
			System.out.println("\n\t1.FIFO\n\t2.LRU\n\t3.Optimal\n\t4.Exit\nEnter the choice: ");
			choice = sc.nextInt();
			switch(choice)
			{
			case 1:
				//FIFO
				int ap=0,rp=0,flag=0;
				for(int i=0;i<m;i++)
				{
					flag = 0;
					if(check(frame,pg[i],size)==true)
					{
						//do nothing
					}
					else
					{
						if(frame[ap]==-1)
						{
							frame[ap]=pg[i];
							ap=(ap+1)%size;
							ff++;
							flag=1;
						}
						else
						{
							frame[rp]=pg[i];
							rp=(rp+1)%size;
							ff++;
							flag=1;
						}
					}
					System.out.print(pg[i]+"\t");
					for(int j=0;j<size;j++)
					{
						if(frame[j]!=-1)
							System.out.print(frame[j]+" ");
						else
							System.out.print("- ");
					}
					if(flag==1)
						System.out.println("\tF"+ff);
					else
						System.out.println("");
				}
				System.out.println("Page Hit: "+(m-ff));
				System.out.println("Page Miss: "+ff);
				break;
			case 2:
				//LRU
				int apl=0,rpl=0,flagl=0;
				for(int i=0;i<m;i++)
				{
					flagl=0;
					if(check(frame,pg[i],size)==true)
					{
						//do nothing
					}
					else
					{
						if(frame[apl]==-1)
						{
							frame[apl]=pg[i];
							apl=(apl+1)%size;
							ffl++;
							flagl=1;
						}
						else
						{
							int count=0;
							int[] arr = new int[size];
							for(int x=0;x<size;x++)
								arr[x]=-1;
							for(int k=i-1;k>-1;k--)
							{
								for(int l=0;l<size;l++)
								{
									if(pg[k]==frame[l])
									{
										arr[count]=l;
										count++;
										break;
									}
								}
								if(count==(size-1))
									break;
							}
							for(int mn=0;mn<size;mn++)
							{
								if(check(arr,mn,size)==false)
								{
									rpl=mn;
									break;
								}
							}
							frame[rpl]=pg[i];
							flagl=1;
							ffl++;
						}
					}
					System.out.print(pg[i]+"\t");
					for(int j=0;j<size;j++)
					{
						if(frame[j]!=-1)
							System.out.print(frame[j]+" ");
						else
							System.out.print("- ");
					}
					if(flagl==1)
						System.out.println("\tF"+ffl);
					else
						System.out.println("");
				}
				System.out.println("Page Hit: "+(m-ffl));
				System.out.println("Page Miss: "+ffl);
				break;
			case 3:
				//OPT
				int apo=0,rpo=0,flago=0;
				for(int i=0;i<m;i++)
				{
					flago=0;
					if(check(frame,pg[i],size)==true)
					{
						//do nothing
					}
					else
					{
						if(frame[apo]==-1)
						{
							frame[apo]=pg[i];
							apo=(apo+1)%size;
							ffo++;
							flago=1;
						}
						else
						{
							int count=0;
							int[] arr = new int[size];
							for(int x=0;x<size;x++)
								arr[x]=-1;
							for(int k=i+1;k<m;k++)
							{
								for(int l=0;l<size;l++)
								{
									if(pg[k]==frame[l])
									{
										if(check(arr,l,size)==false)
										{
											arr[count]=l;
											count++;
										}
										break;
									}
								}
								if(count==(size-1))
									break;
							}
							for(int mn=0;mn<size;mn++)
							{
								if(check(arr,mn,size)==false)
								{
									rpo=mn;
									break;
								}
							}
							frame[rpo]=pg[i];
							flago=1;
							ffo++;
						}
					}
					System.out.print(pg[i]+"\t");
					for(int j=0;j<size;j++)
					{
						if(frame[j]!=-1)
							System.out.print(frame[j]+" ");
						else
							System.out.print("- ");
					}
					if(flago==1)
						System.out.println("\tF"+ffo);
					else
						System.out.println("");
				}
				System.out.println("Page Hit: "+(m-ffo));
				System.out.println("Page Miss: "+ffo);
				break;
			case 4:
				System.exit(0);
			default:
				System.out.println("Invalid input.");
			}
		}
	}
	//Functions
	public static boolean check(int frame[],int page,int size)
	{
		for(int i=0;i<size;i++)
		{
			if(frame[i]==page)
				return true;
		}
		return false;
	}
}
