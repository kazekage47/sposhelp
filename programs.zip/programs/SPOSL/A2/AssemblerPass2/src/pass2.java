import java.io.*;
import java.util.*;
public class pass2 {
	public static void main(String args[]) throws Exception {
		BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("/root/Documents/TE Sem II/SPOSL/Final/A2/AssemblerPass2/src/in.txt")));
		PrintWriter out=new PrintWriter(new BufferedWriter(new FileWriter("src/out.txt")));
		String s,res;
		func f=new func();
		s=in.readLine();
		while(s!=null)
		{
			StringTokenizer st = new StringTokenizer(s," ");
			int l=st.countTokens();
			String[] a=new String[l];
			for(int i=0;i<l;i++)
			{
				a[i]=st.nextToken();
			}
			res=f.searchpot(a);
			if(res!=null)
				out.write(res+"\n");
			s=in.readLine();
		}
		in.close();
		out.close();
	}
}