import java.io.*;
import java.util.*;
public class func {
	int[][] bt=new int[16][2];
	int br=0;
	public String searchpot(String ap[]) throws Exception {
		String ret=null;
		switch(ap[1])
		{
		case "USING":
			using(ap);
			break;
		case "END":
			ret=ap[0]+" "+ap[1];
			break;
		default:
			ret=searchmot(ap);
			if(ret==null)
			{
				ret=ap[0]+" "+ap[1];
			}
		}
		return ret;
	}
	public String searchmot(String am[]) throws Exception {
		String retm=null;
		BufferedReader inmot=new BufferedReader(new InputStreamReader(new FileInputStream("/home/akshit/workspace/Pass2/src/mot.txt")));
		String sm=inmot.readLine();
		while(sm!=null)
		{
			if(sm.startsWith(am[1]))
			{
				StringTokenizer stm=new StringTokenizer(sm," ");
				stm.nextToken();
				String hex=stm.nextToken();
				String r;
				if(!am[1].endsWith("R"))
				{
					r=processoperand(am[2]);
				}
				else
				{
					r=am[2];
				}
				retm=am[0]+" "+hex+" "+r;
				break;
			}
			sm=inmot.readLine();
		}
		inmot.close();
		return retm;
	}
	public String processoperand(String po) throws Exception {
		String retpo=null;
		StringTokenizer stp=new StringTokenizer(po,",");
		int reg=Integer.parseInt(stp.nextToken());
		String name=stp.nextToken();
		BufferedReader inpos = new BufferedReader(new InputStreamReader(new FileInputStream("/home/akshit/workspace/Pass2/src/st.txt")));
		BufferedReader inpol = new BufferedReader(new InputStreamReader(new FileInputStream("/home/akshit/workspace/Pass2/src/lt.txt")));
		if(name.startsWith("="))
		{
			String sl=inpol.readLine();
			while(sl!=null)
			{
				if(sl.startsWith(name))
				{
					StringTokenizer stl=new StringTokenizer(sl," ");
					stl.nextToken();
					int address=Integer.parseInt(stl.nextToken())-bt[br][1];
					retpo=address+"(0,"+br+")";
					break;
				}
				sl=inpol.readLine();
			}
		}
		else
		{
			String ss=inpos.readLine();
			while(ss!=null)
			{
				if(ss.startsWith(name))
				{
					StringTokenizer sts=new StringTokenizer(ss," ");
					sts.nextToken();
					int address=Integer.parseInt(sts.nextToken())-bt[br][1];
					retpo=address+"(0,"+br+")";
					break;
				}
				ss=inpos.readLine();
			}
		}
		inpos.close();
		inpol.close();
		return retpo;
	}
	public void using(String as[]) throws Exception {
		int lc=Integer.parseInt(as[0]);
		StringTokenizer stu=new StringTokenizer(as[2],",");
		String val=stu.nextToken();
		if(!val.equals("*"))
		{
			lc=Integer.parseInt(val);
		}
		int reg=Integer.parseInt(stu.nextToken());
		br=reg;
		bt[reg][0]=1;
		bt[reg][1]=lc;
	}
}
